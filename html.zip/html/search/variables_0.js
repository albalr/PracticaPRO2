var searchData=
[
  ['arbol_5femparejamiento_166',['arbol_emparejamiento',['../class_torneo.html#a2d7923ba4f50ccb849bf1e121d6638e2',1,'Torneo']]],
  ['arbol_5fresultados_167',['arbol_resultados',['../class_torneo.html#ae11060e0fae1784186a5842f70869569',1,'Torneo']]]
];
