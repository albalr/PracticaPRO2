var searchData=
[
  ['restar_5fpuntos_164',['restar_puntos',['../class_torneo.html#a7b8aa2bc5c3ea3a7c176f7d045599847',1,'Torneo']]]
];
