var searchData=
[
  ['torneo_84',['Torneo',['../class_torneo.html',1,'Torneo'],['../class_torneo.html#aac74f4f1cb5c3f1ab05a9c9ade4b2e8b',1,'Torneo::Torneo()']]],
  ['torneo_2ecc_85',['Torneo.cc',['../_torneo_8cc.html',1,'']]],
  ['torneo_2ehh_86',['Torneo.hh',['../_torneo_8hh.html',1,'']]],
  ['torneo_5factual_87',['torneo_actual',['../class_torneo.html#a33fbe406eeb783ad61994f208a3636ee',1,'Torneo']]],
  ['torneo_5fanterior_88',['torneo_anterior',['../class_torneo.html#a7ddf7a2c065167c25854c5be826a5919',1,'Torneo']]],
  ['torneos_5fdisputados_89',['torneos_disputados',['../class_jugador.html#a1fb5771e4831c35b18cdc2ddf6dac2fc',1,'Jugador']]]
];
