var searchData=
[
  ['torneo_5factual_182',['torneo_actual',['../class_torneo.html#a33fbe406eeb783ad61994f208a3636ee',1,'Torneo']]],
  ['torneo_5fanterior_183',['torneo_anterior',['../class_torneo.html#a7ddf7a2c065167c25854c5be826a5919',1,'Torneo']]],
  ['torneos_5fdisputados_184',['torneos_disputados',['../class_jugador.html#a1fb5771e4831c35b18cdc2ddf6dac2fc',1,'Jugador']]]
];
