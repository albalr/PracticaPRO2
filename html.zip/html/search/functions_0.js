var searchData=
[
  ['actualizar_5festadisticas_5fglobales_108',['actualizar_estadisticas_globales',['../class_cjt__jugadores.html#ac3b9b10172b47b32039c96eb4c8ea50f',1,'Cjt_jugadores']]],
  ['actualizar_5fpuntos_109',['actualizar_puntos',['../class_cjt__jugadores.html#aa7163665ba42327de6c009d8ca95a389',1,'Cjt_jugadores']]],
  ['actualizar_5fpuntos_5fjugador_110',['actualizar_puntos_jugador',['../class_jugador.html#a8e3c3f8e8566dd6065c69231de147f41',1,'Jugador']]],
  ['actualizar_5franking_5fcircuito_111',['actualizar_ranking_circuito',['../class_cjt__jugadores.html#a046b1dc7d7e3029b845647f24ca31a5d',1,'Cjt_jugadores']]],
  ['actualizar_5ftorneos_5fdisputados_112',['actualizar_torneos_disputados',['../class_cjt__jugadores.html#a0c1189a76ee0bc40f50ebbe08043f05e',1,'Cjt_jugadores']]],
  ['anadir_5fjugador_113',['anadir_jugador',['../class_cjt__jugadores.html#a7eba11e5e56b340221f8f2e679199b58',1,'Cjt_jugadores']]],
  ['anadir_5ftorneo_114',['anadir_torneo',['../class_cjt__torneos.html#ab16059b16d8e5a525e5c1a191960c953',1,'Cjt_torneos']]],
  ['arbol_5fganadores_115',['arbol_ganadores',['../class_torneo.html#a3fbab32197e54d35185aea3d85247f7d',1,'Torneo']]]
];
