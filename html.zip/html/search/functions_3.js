var searchData=
[
  ['finalizar_5ftorneo_136',['finalizar_torneo',['../class_cjt__torneos.html#a6c396e462290e1310605fe8e494f7eea',1,'Cjt_torneos']]],
  ['finalizar_5ftorneo_5ft_137',['finalizar_torneo_t',['../class_torneo.html#a42570d6753c7082ed4f780f6a826b43e',1,'Torneo']]]
];
