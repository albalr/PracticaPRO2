var searchData=
[
  ['iniciar_5ftorneo_139',['iniciar_torneo',['../class_cjt__torneos.html#af8089747ef9c9b8b3fb83b20a178c30d',1,'Cjt_torneos']]],
  ['iniciar_5ftorneo_5ft_140',['iniciar_torneo_t',['../class_torneo.html#adaed9ab10409ad1ce356d3f92f610a67',1,'Torneo']]]
];
