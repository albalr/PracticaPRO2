var searchData=
[
  ['ranking_80',['ranking',['../struct_cjt__jugadores_1_1ranking.html',1,'Cjt_jugadores']]],
  ['ranking_5fjugadores_81',['ranking_jugadores',['../class_cjt__jugadores.html#af86840b048244f622008e5d5486fffd6',1,'Cjt_jugadores']]],
  ['restar_5fpuntos_82',['restar_puntos',['../class_torneo.html#a7b8aa2bc5c3ea3a7c176f7d045599847',1,'Torneo']]]
];
