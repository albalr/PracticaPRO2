var searchData=
[
  ['actualizar_5festadisticas_5fglobales_0',['actualizar_estadisticas_globales',['../class_cjt__jugadores.html#ac3b9b10172b47b32039c96eb4c8ea50f',1,'Cjt_jugadores']]],
  ['actualizar_5fpuntos_1',['actualizar_puntos',['../class_cjt__jugadores.html#aa7163665ba42327de6c009d8ca95a389',1,'Cjt_jugadores']]],
  ['actualizar_5fpuntos_5fjugador_2',['actualizar_puntos_jugador',['../class_jugador.html#a8e3c3f8e8566dd6065c69231de147f41',1,'Jugador']]],
  ['actualizar_5franking_5fcircuito_3',['actualizar_ranking_circuito',['../class_cjt__jugadores.html#a046b1dc7d7e3029b845647f24ca31a5d',1,'Cjt_jugadores']]],
  ['actualizar_5ftorneos_5fdisputados_4',['actualizar_torneos_disputados',['../class_cjt__jugadores.html#a0c1189a76ee0bc40f50ebbe08043f05e',1,'Cjt_jugadores']]],
  ['anadir_5fjugador_5',['anadir_jugador',['../class_cjt__jugadores.html#a7eba11e5e56b340221f8f2e679199b58',1,'Cjt_jugadores']]],
  ['anadir_5ftorneo_6',['anadir_torneo',['../class_cjt__torneos.html#ab16059b16d8e5a525e5c1a191960c953',1,'Cjt_torneos']]],
  ['arbol_5femparejamiento_7',['arbol_emparejamiento',['../class_torneo.html#a2d7923ba4f50ccb849bf1e121d6638e2',1,'Torneo']]],
  ['arbol_5fganadores_8',['arbol_ganadores',['../class_torneo.html#a3fbab32197e54d35185aea3d85247f7d',1,'Torneo']]],
  ['arbol_5fresultados_9',['arbol_resultados',['../class_torneo.html#ae11060e0fae1784186a5842f70869569',1,'Torneo']]]
];
