var searchData=
[
  ['ranking_95',['ranking',['../struct_cjt__jugadores_1_1ranking.html',1,'Cjt_jugadores']]]
];
