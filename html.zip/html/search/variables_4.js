var searchData=
[
  ['nombres_5fcategorias_173',['nombres_categorias',['../class_cjt__categorias.html#ac0bc400f3220d43de01e541ef3b63041',1,'Cjt_categorias']]]
];
