var searchData=
[
  ['puntos_5fedicion_5fanterior_162',['puntos_edicion_anterior',['../class_cjt__torneos.html#a551b87d2a917a365b7eb338aeda99570',1,'Cjt_torneos']]],
  ['puntos_5fedicion_5fanterior_5ft_163',['puntos_edicion_anterior_t',['../class_torneo.html#a89b4a11b18ac70ffe5f5a1ab369386b4',1,'Torneo']]]
];
