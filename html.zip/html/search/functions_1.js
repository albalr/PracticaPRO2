var searchData=
[
  ['calcular_5fpuntos_116',['calcular_puntos',['../class_torneo.html#a310371d6804fa86577e75eaebc3e1093',1,'Torneo']]],
  ['categoria_5fmaxima_117',['categoria_maxima',['../class_cjt__categorias.html#a70f2ab3920af5a7e2bbd8de0bcf563bb',1,'Cjt_categorias']]],
  ['cjt_5fcategorias_118',['Cjt_categorias',['../class_cjt__categorias.html#a7f37d9248fd52434470db24fc4783495',1,'Cjt_categorias']]],
  ['cjt_5fjugadores_119',['Cjt_jugadores',['../class_cjt__jugadores.html#af40661f610000ab6febf3ea0de7a451b',1,'Cjt_jugadores']]],
  ['cjt_5ftorneos_120',['Cjt_torneos',['../class_cjt__torneos.html#acc82582b779afd52bbb92c8094d473ac',1,'Cjt_torneos']]],
  ['comp_121',['comp',['../class_cjt__jugadores.html#ac9bb4032defd3a5b9942d383bfbe1857',1,'Cjt_jugadores']]],
  ['consultar_5fcategoria_122',['consultar_categoria',['../class_torneo.html#ac558198d579c88ab11b873ed3cf0953d',1,'Torneo']]],
  ['consultar_5fidentificador_5fcat_123',['consultar_identificador_cat',['../class_cjt__categorias.html#a1b4e2ae7149b255954a53aff1e794bfd',1,'Cjt_categorias']]],
  ['consultar_5fjugador_124',['consultar_jugador',['../class_cjt__jugadores.html#a61e27c0c40ce9027dddbdb10b4c7c2e9',1,'Cjt_jugadores']]],
  ['consultar_5fnombre_5fjugador_125',['consultar_nombre_jugador',['../class_cjt__jugadores.html#ae4c8e368eccc26c78f26849a5d01c987',1,'Cjt_jugadores']]],
  ['consultar_5fposicion_5franking_126',['consultar_posicion_ranking',['../class_jugador.html#a02b4c0eea2052e980642f681c0448eca',1,'Jugador']]],
  ['consultar_5fpuntos_5fcat_5fnivel_127',['consultar_puntos_cat_nivel',['../class_cjt__categorias.html#a51abadef54e127ab450f5bf5eeb87cf6',1,'Cjt_categorias']]]
];
