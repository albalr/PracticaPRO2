var searchData=
[
  ['identificador_170',['identificador',['../struct_cjt__jugadores_1_1ranking.html#ad044f228a67fe741be4d4b57a29fdc84',1,'Cjt_jugadores::ranking::identificador()'],['../struct_torneo_1_1jugador__puntos.html#a7078474a7e97f5f07bd421f3db304ab8',1,'Torneo::jugador_puntos::identificador()']]]
];
