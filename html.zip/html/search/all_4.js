var searchData=
[
  ['generar_5fbintree_5femp_40',['generar_bintree_emp',['../class_torneo.html#a6f617ba9cac0ff7e412d2d206608305e',1,'Torneo']]]
];
