var searchData=
[
  ['juegos_44',['juegos',['../class_jugador.html#ab8ea358b14201e7fad986174d0b04f16',1,'Jugador']]],
  ['jugador_45',['Jugador',['../class_jugador.html',1,'Jugador'],['../class_jugador.html#a232c46f75691af6210096e5972535d71',1,'Jugador::Jugador()']]],
  ['jugador_2ecc_46',['Jugador.cc',['../_jugador_8cc.html',1,'']]],
  ['jugador_2ehh_47',['Jugador.hh',['../_jugador_8hh.html',1,'']]],
  ['jugador_5fpuntos_48',['jugador_puntos',['../struct_torneo_1_1jugador__puntos.html',1,'Torneo']]],
  ['jugadores_49',['jugadores',['../class_cjt__jugadores.html#ae3fc5f98e0f343b039bd7dff0e616ecc',1,'Cjt_jugadores']]]
];
