var searchData=
[
  ['jugador_93',['Jugador',['../class_jugador.html',1,'']]],
  ['jugador_5fpuntos_94',['jugador_puntos',['../struct_torneo_1_1jugador__puntos.html',1,'Torneo']]]
];
