var searchData=
[
  ['identificador_41',['identificador',['../struct_cjt__jugadores_1_1ranking.html#ad044f228a67fe741be4d4b57a29fdc84',1,'Cjt_jugadores::ranking::identificador()'],['../struct_torneo_1_1jugador__puntos.html#a7078474a7e97f5f07bd421f3db304ab8',1,'Torneo::jugador_puntos::identificador()']]],
  ['iniciar_5ftorneo_42',['iniciar_torneo',['../class_cjt__torneos.html#af8089747ef9c9b8b3fb83b20a178c30d',1,'Cjt_torneos']]],
  ['iniciar_5ftorneo_5ft_43',['iniciar_torneo_t',['../class_torneo.html#adaed9ab10409ad1ce356d3f92f610a67',1,'Torneo']]]
];
