var searchData=
[
  ['torneo_165',['Torneo',['../class_torneo.html#aac74f4f1cb5c3f1ab05a9c9ade4b2e8b',1,'Torneo']]]
];
