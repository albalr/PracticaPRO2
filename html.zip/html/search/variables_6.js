var searchData=
[
  ['ranking_5fjugadores_180',['ranking_jugadores',['../class_cjt__jugadores.html#af86840b048244f622008e5d5486fffd6',1,'Cjt_jugadores']]]
];
