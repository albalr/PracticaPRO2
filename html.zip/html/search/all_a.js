var searchData=
[
  ['partidos_71',['partidos',['../class_jugador.html#ad22751abd0143014747f559dcfa63d49',1,'Jugador']]],
  ['pos_5franking_72',['pos_ranking',['../class_jugador.html#a200ee7c036d98654af6fab08b8b909e9',1,'Jugador']]],
  ['posicion_5fanterior_73',['posicion_anterior',['../struct_cjt__jugadores_1_1ranking.html#ae73f204dcbaf3e6525c989229cd5dd89',1,'Cjt_jugadores::ranking']]],
  ['program_2ecc_74',['program.cc',['../program_8cc.html',1,'']]],
  ['puntos_75',['puntos',['../struct_cjt__jugadores_1_1ranking.html#a803ab42a74b305741be856d0da6c5edf',1,'Cjt_jugadores::ranking::puntos()'],['../class_jugador.html#a4e264d857d5a3f1a68cbb13e4b88930f',1,'Jugador::puntos()']]],
  ['puntos_5fedicion_5fanterior_76',['puntos_edicion_anterior',['../class_cjt__torneos.html#a551b87d2a917a365b7eb338aeda99570',1,'Cjt_torneos']]],
  ['puntos_5fedicion_5fanterior_5ft_77',['puntos_edicion_anterior_t',['../class_torneo.html#a89b4a11b18ac70ffe5f5a1ab369386b4',1,'Torneo']]],
  ['puntos_5fnivel_78',['puntos_nivel',['../class_cjt__categorias.html#a6a149e684a49326171de93db15a29298',1,'Cjt_categorias']]],
  ['puntos_5ftorneo_79',['puntos_torneo',['../struct_torneo_1_1jugador__puntos.html#a1d3ea3e57eeb508dfdf8b16985bb0224',1,'Torneo::jugador_puntos']]]
];
