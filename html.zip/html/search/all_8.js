var searchData=
[
  ['main_59',['main',['../program_8cc.html#ae66f6b31b5ad750f1fe042a706a4e3d4',1,'program.cc']]],
  ['modificar_5fjuegos_5fganados_60',['modificar_juegos_ganados',['../class_jugador.html#a7279b4f0bea71946ff5b2ee9315729ad',1,'Jugador']]],
  ['modificar_5fjuegos_5fperdidos_61',['modificar_juegos_perdidos',['../class_jugador.html#ad7bd1f5633964749c6609967957ca5ef',1,'Jugador']]],
  ['modificar_5fpartidos_5fganados_62',['modificar_partidos_ganados',['../class_jugador.html#ae2fd1523570b1ff12df859a3bfbd842a',1,'Jugador']]],
  ['modificar_5fpartidos_5fperdidos_63',['modificar_partidos_perdidos',['../class_jugador.html#a1be9d8641fb0bb946f8964059424e340',1,'Jugador']]],
  ['modificar_5fposicion_5franking_64',['modificar_posicion_ranking',['../class_jugador.html#aa9ee02396b0158d352ec4a3e96d1fda5',1,'Jugador']]],
  ['modificar_5fsets_5fganados_65',['modificar_sets_ganados',['../class_jugador.html#a2be72f789693bb4724592265eb9c8a3f',1,'Jugador']]],
  ['modificar_5fsets_5fperdidos_66',['modificar_sets_perdidos',['../class_jugador.html#a3134ea538969205a3d09ea506c7d71fe',1,'Jugador']]],
  ['modificar_5ftorneos_5fdisputados_67',['modificar_torneos_disputados',['../class_jugador.html#adde213774b223f5200a1936296fad2dd',1,'Jugador']]]
];
