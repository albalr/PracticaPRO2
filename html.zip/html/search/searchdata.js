var indexSectionsWithContent =
{
  0: "acefgijlmnprst",
  1: "cjrt",
  2: "cjpt",
  3: "acefgijlmnprt",
  4: "acijnprst"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables"
};

var indexSectionLabels =
{
  0: "Todo",
  1: "Clases",
  2: "Archivos",
  3: "Funciones",
  4: "Variables"
};

