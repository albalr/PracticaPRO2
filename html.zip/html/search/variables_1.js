var searchData=
[
  ['categoria_168',['categoria',['../class_torneo.html#ad9bec7ef311a416138abb99f3a487b3e',1,'Torneo']]],
  ['circuito_169',['circuito',['../class_cjt__torneos.html#a50fe0162e8c23fab025b90114833e58d',1,'Cjt_torneos']]]
];
