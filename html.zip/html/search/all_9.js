var searchData=
[
  ['nombres_5fcategorias_68',['nombres_categorias',['../class_cjt__categorias.html#ac0bc400f3220d43de01e541ef3b63041',1,'Cjt_categorias']]],
  ['numero_5fjugadores_69',['numero_jugadores',['../class_cjt__jugadores.html#a1fe98992697035cf4002f0788d783d25',1,'Cjt_jugadores']]],
  ['numero_5ftorneos_70',['numero_torneos',['../class_cjt__torneos.html#a7d0e2c45a4956e5a2282e2dde7ec917c',1,'Cjt_torneos']]]
];
